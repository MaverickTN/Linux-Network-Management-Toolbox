# lnmt/__main__.py

import sys
from lnmt.main import main

if __name__ == "__main__":
    # CLI entrypoint: lnmt or python3 -m lnmt
    sys.exit(main())
